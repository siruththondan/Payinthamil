# பைந்தமிழ் - தமிழ் தட்டச்சுப் பயிற்சித் தளம்

 Tamil Typing Practice Site

---

I used pure html, css and js to brush up fundamentals, infact i forgot index.html even is existed😅.